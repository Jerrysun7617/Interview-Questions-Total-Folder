cdnLoaded=!0;
//# sourceMappingURL=staging.hackerrank.net/assets/sourcemaps/cdnping-691df18f10507ce98520c220c2ee3e60.js.map