#include <iostream>
#include <string>
#include <sstream>
#include  <vector>
#include <queue>
#include <list>
#include <stdlib.h>
using namespace std;

typedef class Operations ClassOper;
typedef list <class Operations>  LIST_OPER;

LIST_OPER Oper_List;
class Operations{
    public:

   // Operations();
    Operations(string com,string type,int price, int quantity,string id){
        //Order = order;
        Com = com;
        Type = type;
        Price = price;
        Quantity = quantity;
        ID = id;
    }
    void Match_com(vector <string> operating_string);
    void Print_elemets(void);
    void Oper_Buy_Sell(vector <string> operating_string);
    void Trade(ClassOper Order_first, int quantity1, ClassOper Order_second,int quantity2);
    public:
        //int Order;
        string Com;
        string  Type;
        int     Price;
        int     Quantity;
        string  ID;
};
void Operations::Print_elemets(void)
{
    cout<<Com<<" "<<Type<<" "<<Price<<" "<<Quantity<<" "<<ID<<endl;
}
void Operations::Match_com(vector <string> operating_string){
    if(operating_string.size() == 0)
        cout<<"input wrong"<<endl;

    string COM =  operating_string[0];

    if(!COM.compare("BUY") || !COM.compare("SELL"))
    {
        Oper_Buy_Sell(operating_string);
    }
    else if(!COM.compare( "CANCEL")){

    }
    else if(!COM.compare("MODIFY")){

    }
    else if (!COM.compare("PRINT")){

    }
    else{
            cout<<"input wrong"<<endl;
    }
}
void Operations::Trade(ClassOper Order_first, int quantity1, ClassOper Order_second,int quantity2)
{
    cout<<"TRADE "<<Order_first.ID<<" "<<Order_first.Price<<" "<<quantity1<<" "<<
    Order_second.ID<<" "<<Order_second.Price<<" "<<quantity2<<endl;
}
void Operations::Oper_Buy_Sell(vector <string> operating_string)
{
    char * end;
    int price = static_cast<int>(strtol(operating_string[2].c_str(),&end,10));
    int quantity = static_cast<int>(strtol(operating_string[3].c_str(),&end,10));
    ClassOper MinParameter(operating_string[0],operating_string[1],price,quantity,operating_string[4]);

    if(Oper_List.empty()) // if LIst is empty, push in one
    {
        //cout<<operating_string[0]<<" "<<operating_string[1]<<" "<<price<<" "<<quantity<<" "<<operating_string[4]<<endl;
        Oper_List.push_back(MinParameter);
    }
    else
    {
        list <class Operations>::iterator itor;

        string COM =  operating_string[0];
        if(!COM.compare("BUY"))
        {
            for(itor= Oper_List.begin(); itor !=  Oper_List.end();++itor)
            {
                if(!itor->Com.compare("SELL")) // sell
                {
                    //start to sell
                    if(itor->Price <= MinParameter.Price)
                    {
                            if(itor->Quantity > MinParameter.Quantity)
                            {
                                itor->Quantity  -= MinParameter.Quantity;  // sequence ???

                                Trade(*itor, MinParameter.Quantity,MinParameter,MinParameter.Quantity);
                                break;
                            }
                            else
                            {
                                MinParameter.Quantity -= itor->Quantity;

                                itor = Oper_List.erase()
                            }
                    }

                }
            }
        }
        else
        {

        }
        // compare the price with the data in List

    }
    //cout<<operating_string[0]<<" "<<operating_string[1]<<" "<<operating_string[2]<<" "<<operating_string[3]<<" "<<operating_string[4]<<endl;
}
int main()
{

    string input_line, word;    // first input one line code ending by return
    int sec  = 0;

    while(getline(cin, input_line))
    {
        //cout<<input_line<<endl;
        vector <string> split_input;
		stringstream ss(input_line);
		while (ss >> word)
			split_input.push_back(word);  // input strings

        ClassOper Match_func("COMMAND","TYPE",0,0,"ID");
        Match_func.Match_com(split_input); // adjust the match

         while(Oper_List.size() > 0){
                cout<< " Oper_List.size()   = " <<Oper_List.size()<<endl ;
            ClassOper test = Oper_List.front();
            test.Print_elemets();
            Oper_List.pop_front();
         }

 #ifdef Test_List
        // list a class to test
        ClassOper MinParameter(sec++, split_input[0],split_input[1],1,2,split_input[4]);
        cout<<split_input[0]<<" "<<split_input[1]<<" "<<split_input[2]<<" "<<split_input[3]<<" "<<split_input[4]<<endl;

         Oper_List.push_back(MinParameter);
         if(sec > 1)
         {
             sec = 0;
             while(Oper_List.size() > 0){
                    cout<< " Oper_List.size()   = " <<Oper_List.size()<<endl ;
                ClassOper test = Oper_List.front();
                test.Print_elemets();
                Oper_List.pop_front();
             }
#endif
        /*
		while (!split_input.empty()) {
			word = split_input.front();
			split_input.pop();
             cout<<word;
            if(split_input.size()>= 1)
                cout<<" ";
		}
        */
		cout << endl;
		ss.clear();


    }


    while(1);
    return 0;
}
